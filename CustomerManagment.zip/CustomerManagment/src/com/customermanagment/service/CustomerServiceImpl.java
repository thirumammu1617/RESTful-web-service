package com.customermanagment.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.customermanagment.domain.Customer;
import com.customermanagment.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Resource
	CustomerRepository repository;

	@Override
	@Transactional
	public List<Customer> findAll() {
		return (List<Customer>) repository.findAll();
	}

	@Override
	public Customer findCustomerByID(long id) {
		return repository.findById(id);
	}
}
