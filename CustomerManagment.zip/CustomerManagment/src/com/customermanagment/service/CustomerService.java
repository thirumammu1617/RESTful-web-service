package com.customermanagment.service;

import java.util.List;

import com.customermanagment.domain.Customer;

public interface CustomerService {

	public Customer findCustomerByID(long id);

	public List<Customer> findAll();

}
