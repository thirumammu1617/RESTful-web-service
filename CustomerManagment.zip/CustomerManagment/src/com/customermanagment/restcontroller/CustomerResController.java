package com.customermanagment.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.customermanagment.domain.Customer;
import com.customermanagment.service.CustomerService;

@RestController
@RequestMapping("/CustomerResController")
public class CustomerResController {

	@Autowired
	private CustomerService service;

	@RequestMapping(value = "/customers", method = RequestMethod.GET, produces = "application/json")
	public List<Customer> getUsers() {
		return service.findAll();
	}

	@RequestMapping(value = "/findCustomerByID/{id}/", method = RequestMethod.GET, produces = "application/json")
	public Customer findCustomerByID(@PathVariable("id") String id) {
		return service.findCustomerByID(Long.parseLong(id));
	}

}
